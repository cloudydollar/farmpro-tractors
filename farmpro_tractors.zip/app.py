from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Initialize database
def init_db():
    conn = sqlite3.connect("tractors.db")
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS tractors 
                 (id INTEGER PRIMARY KEY, model TEXT, price INTEGER, image TEXT)''')
    conn.commit()
    conn.close()

init_db()

# Home Page - Show Listings
@app.route("/")
def index():
    conn = sqlite3.connect("tractors.db")
    c = conn.cursor()
    c.execute("SELECT * FROM tractors")
    tractors = c.fetchall()
    conn.close()
    return render_template("index.html", tractors=tractors)

# Sell Page - Upload New Tractors
@app.route("/sell", methods=["GET", "POST"])
def sell():
    if request.method == "POST":
        model = request.form["model"]
        price = request.form["price"]
        image = request.form["image"]  # Store image URL for now

        conn = sqlite3.connect("tractors.db")
        c = conn.cursor()
        c.execute("INSERT INTO tractors (model, price, image) VALUES (?, ?, ?)", (model, price, image))
        conn.commit()
        conn.close()
        
        return redirect("/")

    return render_template("sell.html")

# Delete Listing (After Selling)
@app.route("/delete/<int:id>")
def delete(id):
    conn = sqlite3.connect("tractors.db")
    c = conn.cursor()
    c.execute("DELETE FROM tractors WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
